package km_Services;

public class LoginServiceImpl implements LoginService {

}
