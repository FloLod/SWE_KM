package km_Services;

public interface LoginService {

}
