package km_Services;

public class KlassenServiceImpl implements KlassenService {

}
