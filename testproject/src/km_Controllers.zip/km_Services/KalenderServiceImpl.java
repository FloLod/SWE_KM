package km_Services;

public class KalenderServiceImpl implements KalenderService {

}
