package km_Services;

public interface KlassenService {

}
