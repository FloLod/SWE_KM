package km_Services;

public interface KalenderService {

}
