package km_Services;

public interface NotificationService {

}
