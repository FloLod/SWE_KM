package km_Services;

public class SchuelerServiceImpl implements SchuelerService{

}
