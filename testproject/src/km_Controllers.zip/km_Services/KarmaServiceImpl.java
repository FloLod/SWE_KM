package km_Services;

public class KarmaServiceImpl implements KarmaService {

}
