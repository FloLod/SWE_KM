package km_Entities;

public class CompanyPicture {
	private int companyPicuteID;
	private String path;
	
	public CompanyPicture(){}

	public int getCompanyPicuteID() {
		return companyPicuteID;
	}

	public void setCompanyPicuteID(int companyPicuteID) {
		this.companyPicuteID = companyPicuteID;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	
}
